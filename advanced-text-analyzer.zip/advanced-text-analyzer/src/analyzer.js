/**
 * Advanced Text Analyzer
 * Preprocesses user prompts before sending to GPT
 * Features: cleanup, intent tagging, context injection
 */

export async function advancedTextAnalyzer(rawPrompt) {
    if (!rawPrompt || typeof rawPrompt !== 'string') return '';

    // Step 1: Trim and normalize whitespace
    let cleaned = rawPrompt.trim().replace(/\s+/g, ' ');

    // Step 2: Basic intent detection (expandable)
    let contextHint = '';
    if (/weather|forecast/i.test(cleaned)) {
        contextHint = '[Intent: Weather]';
    } else if (/news|headline/i.test(cleaned)) {
        contextHint = '[Intent: News]';
    } else if (/joke|funny/i.test(cleaned)) {
        contextHint = '[Intent: Humor]';
    }

    // Step 3: Context-aware prompt building
    const finalPrompt = \`\${contextHint} \${cleaned}\`.trim();

    return finalPrompt;
}

// Optional: Hook for form integration
export function attachAnalyzerToForm(promptInputId, submitButtonId, callback) {
    const promptInput = document.getElementById(promptInputId);
    const submitButton = document.getElementById(submitButtonId);

    if (!promptInput || !submitButton) {
        console.warn("Text Analyzer: Input or Button ID not found.");
        return;
    }

    submitButton.addEventListener("click", async (e) => {
        e.preventDefault();
        const rawPrompt = promptInput.value;
        const refinedPrompt = await advancedTextAnalyzer(rawPrompt);
        callback(refinedPrompt);
    });
}
